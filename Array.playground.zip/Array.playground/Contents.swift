import UIKit

/// Array Programs
///

////1. Reverse Array
///Input:[2, 4, 1, 9, 6, 10, 8]
///Output:[8, 10, 6, 9, 1, 4, 2]

let inputArray = [2, 4, 1, 9, 6, 10, 8]

func reverseArray(array: [Int]) -> [Int] {
    var resultArray = array
    let mid = array.count/2
    
    var startPoint = 0
    var endPoint = resultArray.count - 1
    
    
    while startPoint < mid && endPoint < resultArray.count {
        
        ///Swapping start point with enad point
        let temp = resultArray[startPoint]
        resultArray[startPoint] = resultArray[endPoint]
        resultArray[endPoint] = temp
        
        ///incrementing startPoint + 1
        startPoint += 1
        
        ///Decrementing endPoint - 1
        endPoint -= 1
    }
    
    
    return resultArray
}

///Optimise approach
///
func reverse(array: [Int]) -> [Int] {
    var resultArray = array
    let mid = resultArray.count/2
    for i in 1...mid {
    let temp = resultArray[i - 1]
        resultArray[i - 1] = resultArray[resultArray.count - i]
        resultArray[resultArray.count - i]  = temp
    }
    return resultArray
}

//print(reverseArray(array: inputArray))
//print(reverse(array: inputArray))
///-------------------------------------------------------------------///
///-------------------------------------------------------------------///

///2. Array Rotation
///Rotate the array from index
///Input:[2, 4, 1, 9, 6, 10, 8], fromIndex = 4
///Output:[6, 10, 8, 2, 4, 1, 9]
///Use cases: Music Playlist when user play 4th song from the playlist rest of the some quead after that
///
func rotate(array: [Int], from index: Int) -> [Int] {
    var resulArray = [Int]()
    
    guard index < array.count else { return array}
    
    for i in index..<array.count {
        resulArray.append(array[i])
    }
    
    for i in 0..<index {
        resulArray.append(array[i])
    }
    
    return resulArray
}
///Optimise Approch
///
func rotateOptimise(array:[Int], from index: Int) -> [Int] {
    var resultArray = [Int]()
    var previousElements = [Int]()
    for i in 0..<array.count {
        if i == index || resultArray.count > 0 {
            resultArray.append(array[i])
        } else {
            previousElements.append(array[i])
        }
        
    }
    resultArray += previousElements
    return resultArray
}
//Custom closure for array rotaion
let rotateClosure = { (array: [Int], index: Int) -> [Int] in
    return rotate(array: array, from: index)
}
//print("Rotated Array:\(rotate(array: inputArray, from: 4))")
//print("Rotated Array:\(rotateOptimise(array: inputArray, from: 4))")
//print(rotateClosure(inputArray, 4))
///-------------------------------------------------------------------///
///-------------------------------------------------------------------///


